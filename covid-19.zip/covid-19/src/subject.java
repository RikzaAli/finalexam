/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author A
 */
import java.util.ArrayList;
import java.util.List;

  
    public class subject {

    static void setState(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    static void setstate(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
private List<observer> observers = new ArrayList<observer>();
private int id;
public int getid() {
return id;
}
public void setid(int id) {
this.id = id;
notifyAllObservers();
}
public void attach(observer observer){
observers.add(observer);
}
public void notifyAllObservers(){
for (observer observer : observers) {
observer.update();
}
}
}



   




    
       
