/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author A
 */
public class patterndemo  {
    
   public static void main(String[] args) {
subject obj = new subject();
       
new observeradministration();
new student();
System.out.println("id: 45");
subject.setstate(15);
System.out.println("id: 56");
subject.setState(10);
    
}

    
}
