/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author A
 */
public class observeradministration extends observer{

    private final subject id;
    
   
public observeradministration(subject id){
this.id = id;
this.id.attach(this);
}
@Override
public void update() {

    
}
}
